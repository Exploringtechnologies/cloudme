<?php

use Common\Pages\LoadCustomPageMenuItems;

return [
    [
        'name' => 'Custom Page',
        'itemsLoader' => LoadCustomPageMenuItems::class,
    ]
];
