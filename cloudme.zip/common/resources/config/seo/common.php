<?php

return [
    [
        'property' => 'og:site_name',
        'content' => '{{site_name}}',
    ],
    [
        'name' => 'twitter:card',
        'content' => 'summary',
    ],
];
