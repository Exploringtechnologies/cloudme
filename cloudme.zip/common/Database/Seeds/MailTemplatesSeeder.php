<?php namespace Common\Database\Seeds;

use Illuminate\Database\Seeder;

class MailTemplatesSeeder extends Seeder
{
    /**
     * @return void
     */
    public function run()
    {
        //
    }
}
