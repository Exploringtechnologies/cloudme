<?php

return [
    '*' => \App\Services\Entries\DriveUploadResponseTransformer::class,
];
